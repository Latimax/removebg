// Default function to render selectors

function $(selector) {
    return document.querySelector(selector);
}


// Get all selectors

let frm = $('#frm');
let submit = $('#btn');
let image = $('#displayImage');
let error = $('#error');
let img = $('#img');

// Add event listener

frm.onsubmit = (e) => {
    // Stop the browser from submitting the form
    e.preventDefault();
}
//Function for alert messages
function display_msg(type, message) {

    error.classList.add(type);
    error.innerHTML = message;
    error.style.display = "block";
}

// Add onclick to btn & img then add onchange to for handling images
// Use async & await to handle image upload

submit.onclick = async () => {
    error.innerHTML = "Processing...";
    submit.classList.add("disabled");

    // Get the value to validate if image is uploaded or not
    let files = img.value;
    if (files == "") {
        display_msg("success", "Please upload an image");
        return false;
    }

    let compressimg = await compressImg(img.files[0]); // Pass image file

    //Get the form data
    let formData = new FormData(frm);

    formData.append('action', 'remove_bg');
    formData.append('compress', compressimg);

    let response = await fetchData(formData); // Pass formdata frome fetchData

    if (response) {
        if (response.status == "success") {
            display_msg('success', response.message);
            submit.innerHTML = "Remove";
            image.src = response.output;

            image.classList.add("imgset");
        } else {
            display_msg("error", response.message);

        }
    }
}

// Function to send fetch api and send req to php
async function fetchData(data) {
    let result = await fetch("process.php", {
        method: 'POST',
        body: data
    });

    // return JSON
    let response = result.json();
    return response;

}


//Upload image action

image.onclick = () => {
    img.click()
}

//onchange evenet to get file & validate type & szie
img.onchange = (e) => {
    if (!e.target.files[0]) return;
    let files = img.files[0];
    if (files) {
        let type = files.type;
        let size = files.size;
        let ext = ["image/jpeg", "image/png", "image/jpg"];

        if (!ext.includes(type)) {
            display_msg("error", "Please upload a valid image");
            e.target.value = ""; //Empty the image
            return false;
        } else if (size > 3000000) {

            submit.classList.remove("disabled");
            display_msg("error", "Image size should be less than 3MB");
            e.target.value = ""; //Empty the image
            return false;
        }



        submit.classList.remove("disabled");
    }
}
// Function to compress img
async function compressImg(file) {

    return new Promise((resolve, reject) => {
        let reader = new FileReader();
        let types = file.type;

        reader.onload = async (e) => {
            //Create new image
            let img = new Image();
            img.src = e.target.result;
            img.onload = async () => {
                let canvas = document.createElement('canvas');
                let ctx = canvas.getContext('2d');
                let width = img.width;
                let height = img.height;
                let aspectRatio = width / height;

                if (width > 256 || height > 256) {
                    if (width > height) {
                        height = Math.floor(600 / aspectRatio);
                        width = 800;
                    } else {
                        width = Math.floor(800 * aspectRatio);
                        height = 600;
                    }
                }

                //Lets draw the image on the canvas
                canvas.width = width;
                canvas.height = height;
                ctx.drawImage(img, 0, 0, width, height);

                // Now return blob version of compress image

                try {
                    let blob = new Promise(
                        (resolve) => canvas.toBlob(resolve, types, 0.9));
                    resolve(blob)
                } catch (error) {
                    reject(error)
                }

            };

            img.src = e.target.result; // Read the file as data URL
        };

        // reader.onerror = reject(error);
        reader.readAsDataURL(file);

    })



    reader.readAsDataURL(file);
    return null;

}