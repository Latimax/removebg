<?php

function makeMsg($status = '', $msg = '') : array {
    return [
        "status" => $status,
        "msg" => $msg
    ];
}

$arr = makeMsg("error", "Invalid Request");


if(isset($_POST['action'])){
    $action = $_POST['action'];

    if($action == "remove_bg"){
        //Use shell_exec to send files to python
        $compress = $_FILES['compress']['tmp_name'];

        // 2>&1 print waht we getting from python
        $command = __DIR__ . "/venv/Scripts/python " . __DIR__ . "/process.py  $compress 2>&1";
        $execute = shell_exec($command);

        $arr = [
            'status' => !$execute ? "error" : "success",
            "msg" => !$execute ? "Try another image" : "Background removed",
            "output" => !$execute ? "not_found" : "data:image/png;base64,". $execute
        ];
    }
}

echo json_encode($arr);

?>