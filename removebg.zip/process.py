# command to setup python env
# pip install virtualenv
# virtualenv venv

import sys
import base64
import rembg
from rembg import remove

def remove_bg(input_f):
    try:
        with open(input_f, 'rb') as f:
            i = f.read()
            o = remove(i)
        return  base64.b64encode(o).decode("utf-8")
    except Exception as e:
        return False
    
if __name__ == "__main__":
    input_ = sys.argv[1]
    process_ = remove_bg(input_)
    print(process_)
    
    